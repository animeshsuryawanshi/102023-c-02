const express = require('express');
const mysql = require('mysql');

const bodyParser = require('body-parser');
const config = require('config');
const app = express();
const port = 9898;



const connectionDetails = {
    host: config.get("dbSettings.host"),
    user:config.get("dbSettings.user"),
    password: config.get("dbSettings.password"),
    database:config.get("dbSettings.database"),
 }


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  next();
});


app.get("/",(request,response)=>{
    var connection = mysql.createConnection(connectionDetails);
    connection.query("select * from ship", (error, result)=>{
        if(error==null)
        {
            response.setHeader("Content-Type","application/json");
            
            var data = JSON.stringify(result);
            connection.end();
            response.send(data);

        }
        else
        {
            response.setHeader("Content-Type","application/json");
            response.send(error);
        }

    })
})



app.post("/",(request,response)=>{
    console.log(request.body);
    var connection = mysql.createConnection(connectionDetails);
    var statement = `insert into ship values(
         '${request.body.name}', 
        '${request.body.email}', 
        '${request.body.password}')`;

    connection.query(statement, (error, result)=>{
    if(error==null)
    {
    response.setHeader("Content-Type","application/json");

    var data = JSON.stringify(result);
    connection.end();
    response.send(data);
    }
    else
    {
    response.setHeader("Content-Type","application/json");
    response.send(error);
    }

    })
})

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
